
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.io.File;
import java.util.Scanner;


public class ChatServer {

    private static ServerSocket serverSocket = null;
    private static Socket clientSocket = null;
    private static final int max_c = 10;
    private static final clientThread[] threads = new clientThread[max_c];

    public static void main(String args[]) {

        int portNumber = 2222;
        try {
            serverSocket = new ServerSocket(portNumber);
        }
        catch (IOException e) {
            System.out.println(e);
        }

     // new client sockets for each connecting client n passing it to a new client thread.
        while (true) {
            try {
                clientSocket = serverSocket.accept();
                int i = 0;
                for (i = 0; i < max_c; i++) {
                    if (threads[i] == null) {
                        (threads[i] = new clientThread(clientSocket, threads)).start();
                        break;
                    }
                }
                if (i == max_c) {
                    PrintStream os = new PrintStream(clientSocket.getOutputStream());
                    os.println("Sry!!Server is busy...");
                    os.close();
                    clientSocket.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }
}

// to tell already present clients that a new one has come/leave
class clientThread extends Thread {

    private DataInputStream is = null;
    private PrintStream os = null;
    private Socket clientSocket = null;
    private final clientThread[] threads;
    private int maxc;
    
    public String name = null;
    public FileOutputStream out;

    public clientThread(Socket clientSocket, clientThread[] threads) {
        this.clientSocket = clientSocket;
        this.threads = threads;
        maxc = threads.length;
    }

    public void run() {
        int maxc = this.maxc;
        clientThread[] threads = this.threads;

        try {
            is = new DataInputStream(clientSocket.getInputStream());
            os = new PrintStream(clientSocket.getOutputStream());
            os.println("Enter your name-");
            this.name = is.readLine().trim();
            System.out.println(name + "New client connected successfully!!");
            os.println("Hello " + name + " to our chat room.\nTo leave enter /quit in a new line");
            if (!(new File(name)).mkdir()) {
                // Directory creation failed
            }

            for (int i = 0; i < maxc; i++) {
                if (threads[i] != null && threads[i] != this) {
                    threads[i].os.println("*** A new user " + name + " has entered the chat room !! ***");
                }
            }

            while (true) {
                String line = is.readLine();
                if (line.startsWith("/quit")) {
                    break;
                }
                System.out.print(line);
                int choice = Integer.parseInt(line);

                switch (choice) {
                    case 1:
                        String line1 = is.readLine();
                        String line2 = is.readLine();
                        for (int i = 0; i < maxc; i++) {
                            if (threads[i] != null) {
                                //System.out.println("hi");
                                if (threads[i].name.equals(line1)) {
                                    threads[i].os.println("<" + name + ">: " + line2);
                                }
                            }
                        }
                        break;

                    case 2:
                        String line3 = is.readLine();
                        for (int i = 0; i < maxc; i++) {
                            if (threads[i] != null && threads[i] != this) {
                                threads[i].os.println("<" + name + ">: " + line3);
                            }
                        }
                        break;

                    case 3:
                        String line4 = is.readLine();
                        String line5 = is.readLine();
                        for (int i = 0; i < maxc; i++) {
                            if (threads[i] != null) {
                                //System.out.println("hi");
                                if (!threads[i].name.equals(line4)) {
                                    threads[i].os.println("<" + name + ">: " + line5);
                                }
                            }
                        }
                        break;
                        
                    case 4:
                        String cname = is.readLine();
                        String fname = is.readLine();
                        int len = Integer.parseInt(is.readLine());
                        byte[] bytes = new byte[len];
                        is.readFully(bytes,0,len);
                        for (int i = 0; i < maxc; i++) {
                            if (threads[i] != null && threads[i] != this) {
                                if (threads[i].name.equals(cname)){
                                    out = new FileOutputStream(threads[i].name + "\\" + fname);
                                    out.write(bytes);
                                }
                            }
        
                            
                        }
                        out.close();
                        break;
    
                    case 5:
                        String fname1 = is.readLine();
                        int len1 = Integer.parseInt(is.readLine());
                        System.out.println(len1);
                        byte[] bytes1 = new byte[len1];
                        is.readFully(bytes1,0,len1);
                        for (int i = 0; i < maxc; i++) {
                        
                            if (threads[i] != null && threads[i] != this) {
                                out = new FileOutputStream(threads[i].name + "\\" + fname1);
                                out.write(bytes1);
                            }
        
                            
                        }
                        out.close();
                        break;
                    
                    case 6:
                        String cname2 = is.readLine();
                        String fname2 = is.readLine();
                        int len2 = Integer.parseInt(is.readLine());
                        byte[] bytes2 = new byte[len2];
                        is.readFully(bytes2,0,len2);
                        for (int i = 0; i < maxc; i++) {
                            if (threads[i] != null && threads[i] != this) {
                                if (!threads[i].name.equals(cname2)){
                                    out = new FileOutputStream(threads[i].name + "\\" + fname2);
                                    out.write(bytes2);
                                }
                            }
        
                            
                        }
                        out.close();
                        break;    

                    default:
                        System.out.print("<" + name + ">: u choose not to broadcast");
                        os.println("<" + name + ">: u choose not to broadcast");
                }
            }

            for (int i = 0; i < maxc; i++) {
                if (threads[i] != null && threads[i] != this) {
                    threads[i].os.println("*** The user " + name+ " is leaving the chat room !! ***");
                }
            }
            os.println("*** Bye " + name + " ***");

            for (int i = 0; i < maxc; i++) {
                if (threads[i] == this) {
                    threads[i] = null;
                }
            }
            is.close();
            os.close();
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
