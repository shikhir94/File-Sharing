import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MultiThreadChatClient implements Runnable {

  // The client socket
  private static Socket clientSocket = null;
  // The output stream
  private static PrintStream os = null;
  // The input stream
  private static DataInputStream is = null;
  // file input stream
  private static FileInputStream infile = null;
  // file output stream
  private static FileOutputStream outfile = null;
  

  private static BufferedReader inputLine = null;
  private static boolean closed = false;
  private static String fname;
  public static void main(String[] args) {

    // The default port.
    int portNumber = 2222;
    // The default host.
    String host = "192.168.2.3";

    if (args.length < 2) {
      System.out
          .println("Usage: java MultiThreadChatClient <host> <portNumber>\n"
              + "Now using host=" + host + ", portNumber=" + portNumber);
    } else {
      host = args[0];
      portNumber = Integer.valueOf(args[1]).intValue();
    }

    /*
     * Open a socket on a given host and port. Open input and output streams.
     */
    try {
      clientSocket = new Socket(host, portNumber);
      inputLine = new BufferedReader(new InputStreamReader(System.in));
      os = new PrintStream(clientSocket.getOutputStream());
      is = new DataInputStream(clientSocket.getInputStream());
    } catch (UnknownHostException e) {
      System.err.println("Don't know about host " + host);
    } catch (IOException e) {
      System.err.println("Couldn't get I/O for the connection to the host "
          + host);
    }

    /*
     * If everything has been initialized then we want to write some data to the
     * socket we have opened a connection to on the port portNumber.
     */
    if (clientSocket != null && os != null && is != null) {
      try {
          int choice = 0;
        /* Create a thread to read from the server. */
        new Thread(new MultiThreadChatClient()).start();
        os.println(inputLine.readLine().trim());
        Thread.sleep(500);
        while (!closed) {
            System.out.println("1. Send Message");
            System.out.println("2. Broadcast Message");
            System.out.println("3. Blockcast Message");
            System.out.println("4. Send File");
            System.out.println("Enter Your Choice:");
            choice = Integer.parseInt(inputLine.readLine());
            os.println(String.valueOf(choice));
            switch (choice){
                case 1:
                    System.out.println("Enter the client you want to send:");
                    os.println(inputLine.readLine().trim());
                    System.out.println("Enter the message you want to send:");
                    os.println(inputLine.readLine().trim());
                    break;
                case 2:
                    System.out.println("Enter the message you want to broadcast:");
                    os.println(inputLine.readLine());
                    break;
                case 3:
                    System.out.println("Enter the client you dont't want to send:");
                    os.println(inputLine.readLine());
                    System.out.println("Enter the message you want to send:");
                    os.println(inputLine.readLine());
                    break;
                case 4:
                    System.out.println("Enter the name of file you want to send");
                    fname = inputLine.readLine();
                    os.println(fname);
                    File file = new File(fname);
                   /* long len = file.length();
                    byte[] bytes = new byte[(int)len];
                    infile = new FileInputStream(file.getAbsolutePath());
                    infile.read(bytes);
                    System.out.println(bytes.toString());
                    os.write(bytes);*/
                    
                   // Socket sock = servsock.accept();
                    byte[] mybytearray = new byte[(int) file.length()];
                    BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
                    bis.read(mybytearray, 0, mybytearray.length);
                    System.out.println(mybytearray.toString());
                    OutputStream os = clientSocket.getOutputStream();
                    os.write(mybytearray, 0, mybytearray.length);
                    os.flush();
                    
                    break;
                    
                default :
                    System.out.println("inside default");
                    //os.println("inside default");
            }
        } 
        /*
         * Close the output stream, close the input stream, close the socket.
         */
        os.close();
        is.close();
        clientSocket.close();
      } catch (IOException e) {
        System.err.println("IOException:  " + e);
      } catch (InterruptedException ex) {
            Logger.getLogger(MultiThreadChatClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  }

  /*
   * Create a thread to read from the server. (non-Javadoc)
   * 
   * @see java.lang.Runnable#run()
   */
  public void run() {
    /*
     * Keep on reading from the socket till we receive "Bye" from the
     * server. Once we received that then we want to break.
     */
    String responseLine;
    try {
      while ((responseLine = is.readLine()) != null) {
        System.out.println(responseLine);
        if (responseLine.indexOf("*** Bye") != -1)
          break;
      }
      closed = true;
    } catch (IOException e) {
      System.err.println("IOException:  " + e);
    }
  }
}